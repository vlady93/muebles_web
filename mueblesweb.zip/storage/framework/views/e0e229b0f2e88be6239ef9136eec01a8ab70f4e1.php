
<?php $__env->startSection('title', 'Registrar muebles'); ?>
<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
      <section class="site-section" id="about-section"><br><br>
        <div class="container">
          
          <div class="row large-gutters">
            <div class="col-lg-6 mb-5">
  
                <div class="owl-carousel slide-one-item with-dots">
                    <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div><img src=<?php echo e(asset($file->url)); ?> style="width: 520px; height: 520px;" alt="Free website template by Free-Template.co" class="img-fluid"></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
                  </div>
  
            </div>
            <div class="col-lg-6 ml-auto">
              
              <h2 class="section-title mb-3"><?php echo e($producto->nombre); ?></h2>
                  
                 
                  <ul class="list-unstyled ul-check success">
                    <?php $__currentLoopData = $array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><h5><?php echo e($arra); ?></h5></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    
                  </ul>
              
            </div>
          </div>
        </div>
      </section>
  

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mueblesweb\resources\views\admin\producto\show.blade.php ENDPATH**/ ?>