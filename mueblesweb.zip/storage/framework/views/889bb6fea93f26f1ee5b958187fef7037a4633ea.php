
<?php $__env->startSection('title', 'Registrar muebles'); ?>
<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<section class="site-section " id="news-section"><br><br>
    <div class="container  ">
      
      <div class="d-flex justify-content-between align-items-center mb-3 mr-2">
        <h4>Lista de Muebles</h4>                
            <a class="nav-link" href="<?php echo e(route('productos.create')); ?>">
                <span class="btn btn-success btn-sm ">Nuevo Producto</span>
            </a>
    </div>
      <div class="table-responsive">
        <table id="order-listing" class="table">
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Mueble</th>
                    <th colspan="2">Acciones</th>
                    
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>

                        
                        <td><?php echo e($producto->nombre); ?></td>
                        <td> <img src=<?php echo e(asset('image/'.$producto->categoria->imagencategoria)); ?>  width="100" height="100"></td>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('crear-iamgenes')): ?>
                        <td><a class="btn btn-primary" href=<?php echo e(route('producto.pictures',$producto)); ?>>Archivos</a></td>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editar-producto')): ?>
                        <td><a class="btn btn-warning" href=<?php echo e(route('productos.edit',$producto)); ?>>Editar</a></td>
                        <?php endif; ?>
                        
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
      
    </div>
  </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mueblesweb\resources\views\admin\producto\index.blade.php ENDPATH**/ ?>