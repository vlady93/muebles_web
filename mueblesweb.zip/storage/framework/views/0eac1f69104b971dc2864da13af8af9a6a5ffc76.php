
<?php $__env->startSection('title', 'Registrar muebles'); ?>
<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <section class="site-section " id="news-section"><br><br>
        <div class="container bg-light ">

            <div class="d-flex justify-content-between align-items-center mb-3 mr-2">
                <h4>Lista de categorias</h4>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('crear-categoria')): ?>
                    <a class="nav-link" href="<?php echo e(route('categorias.create')); ?>">
                        <span class="btn btn-success btn-sm ">Nueva Categoría</span>
                    </a>
                <?php endif; ?>

            </div>
            <div class="table-responsive">
                <table id="order-listing" class="table">
                    <thead>
                        <tr>
                            <th>Nombre</th>
                            <th>Mueble</th>
                            <th>Acciones</th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>


                                <td><?php echo e($categoria->titulo); ?></td>
                                <td> <img src=<?php echo e(asset('image/' . $categoria->imagencategoria)); ?> width="100"
                                        height="100"></td>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editar-categoria')): ?>
                                <td><a href=<?php echo e(route('categorias.edit', $categoria)); ?>> <span
                                  class="btn btn-warning">Editar</span> </a></td>
                                <?php endif; ?>
                                
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mueblesweb\resources\views\admin\categoria\index.blade.php ENDPATH**/ ?>