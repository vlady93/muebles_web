
<?php $__env->startSection('title', 'Registrar muebles'); ?>
<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<section class="site-section" id="news-section" ><br><br>
    <div class="container bg-light ">
      <div class="row mb-5">
        <div class="col-12 text-center mt-3">
          <h2 class="section-title mb-3"><?php echo e($categoria->titulo); ?></h2>
        </div>
      </div>

      <div class="row">
        <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-6 col-lg-4 mb-4 mb-lg-4">
            <div class="h-entry">
              <a href=<?php echo e(route('productos.show',$producto)); ?>><img src=<?php echo e(asset('image/'.$producto->categoria->imagencategoria)); ?> alt="Free website template by Free-Template.co" class="img-fluid" width="300px" height="300px"></a>
              <h2 class="font-size-regular"><?php echo e($producto->nombre); ?></h2>
              
            </div> 
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        
        
      </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mueblesweb\resources\views\admin\categoria\show.blade.php ENDPATH**/ ?>